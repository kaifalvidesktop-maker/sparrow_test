// Video Speed Controller - Sparrow extension
// D faster, S slower, R reset, Z back 10s, X forward 10s, V toggle badge.
(function () {
  var KEY = 'sparrow-vsc:speed';
  var STEP = 0.25, MIN = 0.25, MAX = 16;
  var hudVisible = true;
  var hudTimer = 0;
  var hud = null;
  var lastVideo = null;
  var desired = load();
  var ownChange = new WeakSet();

  function load() {
    try {
      var v = parseFloat(localStorage.getItem(KEY));
      if (v >= MIN && v <= MAX) return v;
    } catch (e) {}
    return 1;
  }
  function save(v) {
    try { localStorage.setItem(KEY, String(v)); } catch (e) {}
  }
  function clamp(v) {
    v = Math.round(v * 100) / 100;
    return Math.min(MAX, Math.max(MIN, v));
  }

  function setRate(video, rate) {
    rate = clamp(rate);
    ownChange.add(video);
    try { video.playbackRate = rate; } catch (e) {}
    return rate;
  }

  function bind(video) {
    if (video.__sparrowVsc) return;
    video.__sparrowVsc = true;
    var apply = function () {
      if (desired !== 1 || video.playbackRate !== 1) setRate(video, desired);
    };
    video.addEventListener('loadstart', apply);
    video.addEventListener('loadedmetadata', apply);
    video.addEventListener('play', function () { lastVideo = video; });
    video.addEventListener('ratechange', function () {
      // a change we did not make (the site's own speed menu) becomes the new speed
      if (ownChange.has(video)) { ownChange.delete(video); return; }
      var r = clamp(video.playbackRate);
      if (r !== desired) { desired = r; save(r); }
    });
    if (video.readyState > 0 || !video.paused) apply();
  }

  function scan(root) {
    var list = (root || document).querySelectorAll ? (root || document).querySelectorAll('video') : [];
    for (var i = 0; i < list.length; i++) bind(list[i]);
  }

  function activeVideo() {
    var vids = Array.prototype.slice.call(document.querySelectorAll('video'));
    if (!vids.length) return null;
    var playing = vids.filter(function (v) { return !v.paused && !v.ended; });
    if (playing.length) return playing[0];
    if (lastVideo && document.contains(lastVideo)) return lastVideo;
    var best = null, area = 0;
    vids.forEach(function (v) {
      var r = v.getBoundingClientRect();
      var a = r.width * r.height;
      if (a > area) { area = a; best = v; }
    });
    return best || vids[0];
  }

  function ensureHud() {
    if (hud && hud.isConnected) return hud;
    hud = document.createElement('div');
    hud.id = 'sparrow-vsc-hud';
    var fe = document.fullscreenElement;
    var parent = fe && fe.tagName !== 'VIDEO' ? fe : (document.body || document.documentElement);
    parent.appendChild(hud);
    return hud;
  }

  function showHud(video, text) {
    if (!hudVisible || !video) return;
    var el = ensureHud();
    var r = video.getBoundingClientRect();
    el.textContent = text;
    el.style.left = Math.max(8, r.left + 12) + 'px';
    el.style.top = Math.max(8, r.top + 12) + 'px';
    el.classList.add('show');
    clearTimeout(hudTimer);
    hudTimer = setTimeout(function () { el.classList.remove('show'); }, 1200);
  }

  function fmt(v) { return (Math.round(v * 100) / 100) + '\u00D7'; }

  function typing(e) {
    var t = e.target;
    if (!t) return false;
    var tag = (t.tagName || '').toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable;
  }

  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.altKey || e.metaKey || typing(e)) return;
    var key = (e.key || '').toLowerCase();
    if ('dsrzxv'.indexOf(key) < 0 || key.length !== 1) return;
    var video = activeVideo();
    if (!video) return;
    scan(document);

    if (key === 'v') {
      hudVisible = !hudVisible;
      if (hudVisible) showHud(video, fmt(video.playbackRate));
      else if (hud) hud.classList.remove('show');
      return;
    }
    if (key === 'z' || key === 'x') {
      try { video.currentTime = Math.max(0, video.currentTime + (key === 'x' ? 10 : -10)); } catch (err) {}
      showHud(video, key === 'x' ? '+10s' : '\u221210s');
      return;
    }
    var next = key === 'd' ? video.playbackRate + STEP : key === 's' ? video.playbackRate - STEP : 1;
    desired = setRate(video, next);
    save(desired);
    // keep every other video on the page in sync
    document.querySelectorAll('video').forEach(function (v) { if (v !== video) setRate(v, desired); });
    showHud(video, fmt(desired));
    e.stopPropagation();
  }, true);

  scan(document);
  new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var added = muts[i].addedNodes;
      for (var j = 0; j < added.length; j++) {
        var n = added[j];
        if (n.nodeType !== 1) continue;
        if (n.tagName === 'VIDEO') bind(n);
        else scan(n);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
})();

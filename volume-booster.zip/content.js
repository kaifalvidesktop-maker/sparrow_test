// Volume Booster - Sparrow extension
// Alt+Up louder, Alt+Down quieter, Alt+0 reset. 0% - 600%.
(function () {
  var KEY = 'sparrow-vb:level';
  var STEP = 0.5, MAX = 6;
  var level = load();
  var ctx = null;
  var graphs = new WeakMap();
  var hud = null, hudTimer = 0;

  function load() {
    try {
      var v = parseFloat(localStorage.getItem(KEY));
      if (v >= 0 && v <= MAX) return v;
    } catch (e) {}
    return 1;
  }
  function save() { try { localStorage.setItem(KEY, String(level)); } catch (e) {} }

  function canBoost(el) {
    var src = el.currentSrc || el.src || '';
    if (!src || src.indexOf('blob:') === 0 || src.indexOf('data:') === 0) return true;
    try { if (new URL(src, location.href).origin === location.origin) return true; } catch (e) {}
    return el.crossOrigin !== null && el.crossOrigin !== undefined;
  }

  function getCtx() {
    if (ctx) return ctx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  function connect(el) {
    var g = graphs.get(el);
    if (g) return g;
    var c = getCtx();
    if (!c) return null;
    try {
      var src = c.createMediaElementSource(el);
      var gain = c.createGain();
      var comp = c.createDynamicsCompressor();
      comp.threshold.value = -3;
      comp.knee.value = 0;
      comp.ratio.value = 20;
      comp.attack.value = 0.003;
      comp.release.value = 0.1;
      src.connect(gain);
      gain.connect(comp);
      comp.connect(c.destination);
      g = { gain: gain };
      graphs.set(el, g);
      return g;
    } catch (e) {
      return null;
    }
  }

  function apply(el) {
    if (level === 1 && !graphs.has(el)) return true; // untouched until the user boosts
    if (!canBoost(el)) return false;
    var g = connect(el);
    if (!g) return false;
    g.gain.gain.value = level;
    return true;
  }

  function mediaList() {
    return Array.prototype.slice.call(document.querySelectorAll('video, audio'));
  }

  function applyAll() {
    var blocked = false, any = false;
    mediaList().forEach(function (el) {
      any = true;
      if (!apply(el)) blocked = true;
    });
    return { any: any, blocked: blocked };
  }

  function ensureHud() {
    if (hud && hud.isConnected) return hud;
    hud = document.createElement('div');
    hud.id = 'sparrow-vb-hud';
    (document.body || document.documentElement).appendChild(hud);
    return hud;
  }

  function showHud(text, pct, hot) {
    var el = ensureHud();
    el.innerHTML = '';
    var t = document.createElement('div');
    t.textContent = text;
    el.appendChild(t);
    if (pct != null) {
      var bar = document.createElement('div'); bar.className = 'bar';
      var fill = document.createElement('div'); fill.className = 'fill' + (hot ? ' hot' : '');
      fill.style.width = Math.min(100, pct) + '%';
      bar.appendChild(fill); el.appendChild(bar);
    }
    el.classList.add('show');
    clearTimeout(hudTimer);
    hudTimer = setTimeout(function () { el.classList.remove('show'); }, 1400);
  }

  function resume() {
    if (ctx && ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
  }

  function setLevel(next) {
    level = Math.round(Math.min(MAX, Math.max(0, next)) * 100) / 100;
    save();
    var r = applyAll();
    resume();
    if (!r.any) { showHud('No video or audio on this page'); return; }
    if (r.blocked) { showHud("This site's media can't be boosted (cross-origin)"); return; }
    showHud('Volume ' + Math.round(level * 100) + '%', (level / MAX) * 100, level > 2);
  }

  document.addEventListener('keydown', function (e) {
    if (!e.altKey || e.ctrlKey || e.metaKey) return;
    var k = e.key;
    if (k === 'ArrowUp') { setLevel(level + STEP); }
    else if (k === 'ArrowDown') { setLevel(level - STEP); }
    else if (k === '0') { setLevel(1); }
    else { return; }
    e.preventDefault();
    e.stopPropagation();
  }, true);

  // media that appears later (single-page sites) follows the saved level
  document.addEventListener('play', function (e) {
    if (e.target && (e.target.tagName === 'VIDEO' || e.target.tagName === 'AUDIO')) {
      if (level !== 1) { apply(e.target); resume(); }
    }
  }, true);
  document.addEventListener('click', resume, true);
})();

// Color Picker - Sparrow extension. Alt+C = pick a color.
(function () {
  var HKEY = 'sparrow-cp:history';
  var panel = null, closeTimer = 0;

  function hex2(n) { n = Math.max(0, Math.min(255, Math.round(n))); return (n < 16 ? '0' : '') + n.toString(16); }
  function toHex(r, g, b) { return ('#' + hex2(r) + hex2(g) + hex2(b)).toUpperCase(); }
  function parseHex(h) {
    h = String(h).replace('#', '');
    if (h.length === 3) h = h.split('').map(function (c) { return c + c; }).join('');
    if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  function toHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b), h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return 'hsl(' + Math.round(h) + ', ' + Math.round(s * 100) + '%, ' + Math.round(l * 100) + '%)';
  }
  function cssToRgb(c) {
    var m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+))?/.exec(c || '');
    if (!m) return null;
    var a = m[4] === undefined ? 1 : parseFloat(m[4]);
    return a === 0 ? null : [+m[1], +m[2], +m[3]];
  }

  function history() {
    try { var h = JSON.parse(localStorage.getItem(HKEY) || '[]'); return Array.isArray(h) ? h : []; } catch (e) { return []; }
  }
  function remember(hex) {
    var h = history().filter(function (x) { return x !== hex; });
    h.unshift(hex);
    try { localStorage.setItem(HKEY, JSON.stringify(h.slice(0, 8))); } catch (e) {}
  }

  function copy(text, msgEl) {
    var done = function () { if (msgEl) msgEl.textContent = 'Copied ' + text; };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text); done(); });
        return;
      }
    } catch (e) {}
    fallbackCopy(text); done();
  }
  function fallbackCopy(text) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
    } catch (e) {}
  }

  function closePanel() {
    clearTimeout(closeTimer);
    if (panel) { panel.remove(); panel = null; }
  }

  function show(hex, note) {
    var rgb = parseHex(hex);
    if (!rgb) return;
    remember(hex);
    closePanel();
    panel = document.createElement('div');
    panel.id = 'sparrow-cp-panel';

    var head = document.createElement('div'); head.className = 'cp-head';
    var title = document.createElement('span'); title.textContent = 'Color Picker';
    var x = document.createElement('button'); x.className = 'cp-x'; x.textContent = '\u2715';
    x.addEventListener('click', closePanel);
    head.appendChild(title); head.appendChild(x);

    var sw = document.createElement('div'); sw.className = 'cp-swatch'; sw.style.background = hex;
    var msg = document.createElement('div'); msg.className = 'cp-msg';
    msg.textContent = note || '';

    panel.appendChild(head); panel.appendChild(sw);
    [['HEX', hex], ['RGB', 'rgb(' + rgb.join(', ') + ')'], ['HSL', toHsl(rgb[0], rgb[1], rgb[2])]].forEach(function (p) {
      var b = document.createElement('button'); b.className = 'cp-val';
      var l = document.createElement('span'); l.textContent = p[0];
      var v = document.createElement('span'); v.textContent = p[1];
      b.appendChild(l); b.appendChild(v);
      b.addEventListener('click', function () { copy(p[1], msg); });
      panel.appendChild(b);
    });

    var hist = document.createElement('div'); hist.className = 'cp-hist';
    history().forEach(function (h) {
      var c = document.createElement('button'); c.className = 'cp-chip'; c.style.background = h; c.title = h;
      c.addEventListener('click', function () { show(h); });
      hist.appendChild(c);
    });
    panel.appendChild(hist); panel.appendChild(msg);
    (document.body || document.documentElement).appendChild(panel);
    copy(hex, msg);
    closeTimer = setTimeout(closePanel, 12000);
  }

  // Fallback when the eyedropper is unavailable: click an element, read its CSS color.
  function inspectMode() {
    var onClick = function (e) {
      e.preventDefault(); e.stopPropagation();
      document.removeEventListener('click', onClick, true);
      var el = e.target, rgb = null;
      while (el && el.nodeType === 1 && !rgb) {
        rgb = cssToRgb(getComputedStyle(el).backgroundColor);
        el = el.parentElement;
      }
      if (!rgb) rgb = cssToRgb(getComputedStyle(e.target).color) || [255, 255, 255];
      show(toHex(rgb[0], rgb[1], rgb[2]), 'Element color (eyedropper not available)');
    };
    document.addEventListener('click', onClick, true);
  }

  function pick() {
    if (typeof window.EyeDropper === 'function') {
      var dropper;
      try { dropper = new window.EyeDropper(); } catch (e) { inspectMode(); return; }
      dropper.open().then(function (r) { show(String(r.sRGBHex).toUpperCase()); }, function () {});
    } else {
      inspectMode();
    }
  }

  document.addEventListener('keydown', function (e) {
    if (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === 'c' || e.key === 'C')) {
      e.preventDefault(); e.stopPropagation();
      pick();
    }
    if (e.key === 'Escape' && panel) closePanel();
  }, true);
})();

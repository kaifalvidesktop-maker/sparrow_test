// Page Translator - Sparrow extension
// Alt+T = panel (translate page / show original), Alt+S = translate selected text.
(function () {
  var LKEY = 'sparrow-pt:lang';
  var LANGS = [
    ['en', 'English'], ['bn', 'Bangla (\u09AC\u09BE\u0982\u09B2\u09BE)'], ['hi', 'Hindi'], ['ur', 'Urdu'], ['ar', 'Arabic'],
    ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'], ['it', 'Italian'], ['pt', 'Portuguese'],
    ['ru', 'Russian'], ['ja', 'Japanese'], ['ko', 'Korean'], ['zh-CN', 'Chinese (Simplified)'],
    ['zh-TW', 'Chinese (Traditional)'], ['tr', 'Turkish'], ['id', 'Indonesian'], ['ms', 'Malay'],
    ['th', 'Thai'], ['vi', 'Vietnamese'], ['nl', 'Dutch'], ['pl', 'Polish'], ['uk', 'Ukrainian'],
    ['fa', 'Persian'], ['sv', 'Swedish'], ['ta', 'Tamil'], ['ne', 'Nepali'], ['sw', 'Swahili']
  ];
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, CODE: 1, PRE: 1, TEXTAREA: 1, INPUT: 1, SELECT: 1, OPTION: 1, SVG: 1, CANVAS: 1 };
  var MAX_NODES = 700, BATCH_CHARS = 1400, BATCH_ITEMS = 25, WORKERS = 3;

  var panel = null, tip = null;
  var originals = new Map();
  var busy = false, cancelled = false;

  function getLang() { try { return localStorage.getItem(LKEY) || 'en'; } catch (e) { return 'en'; } }
  function setLang(v) { try { localStorage.setItem(LKEY, v); } catch (e) {} }

  // ---- translation request (through Sparrow's restricted network bridge) ----
  function translateRaw(text, tl) {
    var url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' +
      encodeURIComponent(tl) + '&dt=t&q=' + encodeURIComponent(text);
    return sparrowExt.fetch(url).then(function (res) {
      if (res.status !== 200) throw new Error('Translate service returned ' + res.status);
      var data = JSON.parse(res.text);
      var segs = (data && data[0]) || [];
      return segs.map(function (s) { return s && s[0] ? s[0] : ''; }).join('');
    });
  }

  function translateBatch(texts, tl) {
    var joined = texts.map(function (t) { return t.replace(/\s*[\r\n]+\s*/g, ' '); }).join('\n');
    return translateRaw(joined, tl).then(function (out) {
      var parts = out.split('\n');
      if (parts.length === texts.length) return parts;
      // line count changed: translate one by one so nothing ends up in the wrong place
      var result = [];
      return texts.reduce(function (chain, t, i) {
        return chain.then(function () {
          return translateRaw(t, tl).then(function (o) { result[i] = o; }, function () { result[i] = t; });
        });
      }, Promise.resolve()).then(function () { return result; });
    });
  }

  // ---- page walking ----
  function collect() {
    var items = [];
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = walker.nextNode()) && items.length < MAX_NODES) {
      var v = n.nodeValue;
      if (!v || !/\p{L}/u.test(v)) continue;
      var p = n.parentElement;
      if (!p || SKIP[(p.tagName || '').toUpperCase()]) continue;
      if (p.isContentEditable || (p.closest && p.closest('[contenteditable=""],[contenteditable="true"]'))) continue;
      if (p.closest && p.closest('#sparrow-pt-panel,#sparrow-pt-tip')) continue;
      if (originals.has(n)) continue;
      items.push({ node: n, text: v.trim() });
    }
    return items;
  }

  function makeBatches(items) {
    var batches = [], cur = [], size = 0;
    items.forEach(function (it) {
      var len = encodeURIComponent(it.text).length;
      if (cur.length && (size + len > BATCH_CHARS || cur.length >= BATCH_ITEMS)) {
        batches.push(cur); cur = []; size = 0;
      }
      cur.push(it); size += len;
    });
    if (cur.length) batches.push(cur);
    return batches;
  }

  function applyBatch(batch, outs) {
    batch.forEach(function (it, i) {
      var t = outs[i];
      if (typeof t !== 'string' || !t) return;
      var orig = it.node.nodeValue;
      var lead = (orig.match(/^\s*/) || [''])[0];
      var trail = (orig.match(/\s*$/) || [''])[0];
      originals.set(it.node, orig);
      it.node.nodeValue = lead + t.trim() + trail;
    });
  }

  function translatePage() {
    if (busy) return Promise.resolve();
    var tl = getLang();
    var items = collect();
    if (!items.length) { setStatus('Nothing new to translate.'); return Promise.resolve(); }
    var batches = makeBatches(items);
    var done = 0, failed = 0, next = 0;
    busy = true; cancelled = false;
    setStatus('Translating... 0%');

    function worker() {
      if (cancelled || next >= batches.length) return Promise.resolve();
      var batch = batches[next++];
      return translateBatch(batch.map(function (b) { return b.text; }), tl).then(function (outs) {
        if (!cancelled) applyBatch(batch, outs);
      }, function (err) {
        failed++; lastError = err;
      }).then(function () {
        done++;
        setStatus('Translating... ' + Math.round((done / batches.length) * 100) + '%');
        return worker();
      });
    }
    var lastError = null, pool = [];
    for (var i = 0; i < WORKERS; i++) pool.push(worker());
    return Promise.all(pool).then(function () {
      busy = false;
      if (cancelled) return;
      if (failed === batches.length) setStatus('Could not translate: ' + (lastError && lastError.message || 'network error'), true);
      else if (failed) setStatus('Done, but ' + failed + ' part(s) failed.');
      else setStatus('Translated to ' + langName(tl) + '.');
    });
  }

  function showOriginal() {
    cancelled = true;
    originals.forEach(function (orig, node) { try { node.nodeValue = orig; } catch (e) {} });
    originals.clear();
    busy = false;
    setStatus('Original text restored.');
  }

  function langName(code) {
    for (var i = 0; i < LANGS.length; i++) if (LANGS[i][0] === code) return LANGS[i][1];
    return code;
  }

  // ---- UI ----
  var statusEl = null;
  function setStatus(msg, err) {
    if (!statusEl) return;
    statusEl.textContent = msg || '';
    statusEl.className = 'pt-status' + (err ? ' err' : '');
  }

  function closePanel() { if (panel) { panel.remove(); panel = null; statusEl = null; } }

  function openPanel() {
    if (panel) { closePanel(); return; }
    panel = document.createElement('div');
    panel.id = 'sparrow-pt-panel';

    var head = document.createElement('div'); head.className = 'pt-head';
    var title = document.createElement('span'); title.textContent = 'Page Translator';
    var x = document.createElement('button'); x.className = 'pt-x'; x.textContent = '\u2715';
    x.addEventListener('click', closePanel);
    head.appendChild(title); head.appendChild(x);

    var sel = document.createElement('select');
    LANGS.forEach(function (l) {
      var o = document.createElement('option'); o.value = l[0]; o.textContent = l[1];
      if (l[0] === getLang()) o.selected = true;
      sel.appendChild(o);
    });
    sel.addEventListener('change', function () { setLang(sel.value); });

    var go = document.createElement('button'); go.className = 'pt-btn'; go.textContent = 'Translate this page';
    go.addEventListener('click', function () { setLang(sel.value); translatePage(); });
    var back = document.createElement('button'); back.className = 'pt-btn sec'; back.textContent = 'Show original';
    back.addEventListener('click', showOriginal);

    statusEl = document.createElement('div'); statusEl.className = 'pt-status';
    statusEl.textContent = 'Tip: select text and press Alt+S to translate just that.';

    [head, sel, go, back, statusEl].forEach(function (el) { panel.appendChild(el); });
    (document.body || document.documentElement).appendChild(panel);
  }

  function closeTip() { if (tip) { tip.remove(); tip = null; } }

  function translateSelection() {
    var s = window.getSelection && window.getSelection();
    var text = s ? String(s).trim() : '';
    if (!text) return;
    if (text.length > 1500) text = text.slice(0, 1500);
    var rect = null;
    try { rect = s.getRangeAt(0).getBoundingClientRect(); } catch (e) {}
    closeTip();
    tip = document.createElement('div'); tip.id = 'sparrow-pt-tip';
    tip.textContent = 'Translating...';
    var top = (rect ? rect.bottom : 40) + window.scrollY + 8;
    var left = (rect ? rect.left : 20) + window.scrollX;
    tip.style.top = top + 'px';
    tip.style.left = Math.max(8, Math.min(left, window.scrollX + document.documentElement.clientWidth - 360)) + 'px';
    (document.body || document.documentElement).appendChild(tip);
    var mine = tip;
    translateRaw(text, getLang()).then(function (out) {
      if (tip === mine) mine.textContent = out || '(no translation)';
    }, function (err) {
      if (tip === mine) mine.textContent = 'Could not translate: ' + (err && err.message || 'network error');
    });
  }

  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.metaKey) return;
    if (e.altKey && (e.key === 't' || e.key === 'T')) { e.preventDefault(); e.stopPropagation(); openPanel(); }
    else if (e.altKey && (e.key === 's' || e.key === 'S')) { e.preventDefault(); e.stopPropagation(); translateSelection(); }
    else if (e.key === 'Escape') { closeTip(); }
  }, true);
  document.addEventListener('mousedown', function (e) {
    if (tip && !(e.target.closest && e.target.closest('#sparrow-pt-tip'))) closeTip();
  }, true);
})();
